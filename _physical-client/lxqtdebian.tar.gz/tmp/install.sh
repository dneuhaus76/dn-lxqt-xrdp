#!/bin/bash
#https://duckduckgo.com/?q=bash+script+parameter+passing&t=chromentp&ia=web
#./script.sh -m docker
#CHKHOSTNAMECTL=$(hostnamectl)
#$(systemd-detect-virt) == "docker"

#args
while getopts "m:" opt; do
  case $opt in
    m) mode="$OPTARG" ;;
    *) echo "Invalid option" ;;
  esac
done
echo "Mode: ${mode}"

#vars
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd $SCRIPT_DIR

export ARCH=$(dpkg --print-architecture)
export PRODUCTNAME="$(dmidecode -s system-product-name)"
export DEBIAN_FRONTEND="noninteractive"


# variablen aus file
if [ -f "${SCRIPT_DIR}/environment" ]; then
	source "${SCRIPT_DIR}/environment"
fi
echo "$(env | grep -iv 'LS_COLORS' | sort)"
export TZ="${TZ:-Europe/Zurich}"

if [[ "${mode,,}" == "docker" ]]; then
	echo "(docker) - nehme unnötige Sachen weg"
	# Entfernt unnötige Power-Management-Links aus dem LXQt-Menü
	rm -fv /usr/share/applications/lxqt-hibernate.desktop
	rm -fv /usr/share/applications/lxqt-shutdown.desktop
	rm -fv /usr/share/applications/lxqt-reboot.desktop
	rm -fv /usr/share/applications/lxqt-suspend.desktop
	rm -fv /usr/share/applications/lxqt-leave.desktop
	rm -fv /usr/share/applications/lxqt-lockscreen.desktop
	rm -fv /usr/share/applications/lxqt-config-monitor.desktop
	rm -fv /usr/share/applications/lxqt-config-brightness.desktop
	rm -fv /etc/xdg/autostart/lxqt-xscreensaver-autostart.desktop
fi


# import config, sicherstellen 
apt-get update
apt-get install -fy
dpkg --configure -a


#set reconfiguration
cat <<EOT | debconf-set-selections
locales locales/default_environment_locale      select  ${SYSLANG}
locales locales/locales_to_be_generated multiselect     ${ADDLANG} UTF-8, ${SYSLANG} UTF-8
tzdata  tzdata/Zones/Etc        select  UTC
tzdata  tzdata/Zones/${TZ1}     select  ${TZ2}
keyboard-configuration  keyboard-configuration/modelcode        string  pc105
keyboard-configuration  keyboard-configuration/variant  select  ${VARIANT}
keyboard-configuration  keyboard-configuration/xkb-keymap       select  ${XKB}
EOT


cat <<EOT >/etc/locale.gen
${SYSLANG} UTF-8
${ADDLANG} UTF-8
EOT
dpkg-reconfigure locales

if ! [ -z "${TZ}" ]; then
 echo "[+] set timezone: ${TZ}"
 dpkg-reconfigure tzdata
 ln -snfv /usr/share/zoneinfo/${TZ} /etc/localtime
fi

if ! [ -z "${XKB}" ]; then
 echo "[+] set keyboard: ${XKB}"
 dpkg-reconfigure keyboard-configuration
fi

dpkg-reconfigure hicolor-icon-theme

#locales set detailed winth addlang
if [ -z "${ADDLANG}" ]; then
 echo "[+] set addlang to syslang: ${SYSLANG}"
 export ADDLANG="${SYSLANG}"
fi
cat <<EOT >/etc/default/locale 
LANG="${SYSLANG}"
LANGUAGE="${SYSLANG}:en"
LC_MESSAGES="${SYSLANG}"
LC_NAME="${SYSLANG}"
LC_COLLATE="${ADDLANG}"
LC_MEASUREMENT="${ADDLANG}"
LC_MONETARY="${ADDLANG}"
LC_NUMERIC="${ADDLANG}"
LC_PAPER="${ADDLANG}"
LC_TIME="${ADDLANG}"
LC_ADDRESS="${ADDLANG}"
LC_CTYPE="${ADDLANG}"
LC_IDENTIFICATION="${ADDLANG}"
LC_TELEPHONE="${ADDLANG}"
EOT


# hostname
echo "${COMPUTERNAME}" >/etc/hostname


# hosts
cat  <<EOT >/etc/hosts
127.0.0.1 localhost
127.0.1.1 ${COMPUTERNAME}

# The following lines are desirable for IPv6 capable hosts
::1     ip6-localhost ip6-loopback
fe00::0 ip6-localnet
ff00::0 ip6-mcastprefix
ff02::1 ip6-allnodes
ff02::2 ip6-allrouters
ff02::3 ip6-allhosts
EOT


# users & groups
if ! [ -z "${USRNAME}" ]; then
 echo "[+] add user: ${USRNAME}"
 useradd -m -s /bin/bash -c 'sudo user' -p "${USRPW}" ${USRNAME}
 usermod -aG sudo,audio,adm,render,video ${USRNAME}
 else
 USRNAME='user'
 USRPW='$6$0Dx/oWyy0cXyShrh$NOOVS7.zG..eYOHsgo41NrCpdoquCFIQi.yYajs1PiUbz.ny1o1xoYpp/rIJeOfws4G1qUqqCjw4fW65P7ofC.'
 useradd -m -s /bin/bash -c 'sudo user' -p "${USRPW}" ${USRNAME}
 usermod -aG sudo,audio,adm,render,video ${USRNAME}
fi

# internet user
USRPW='$6$mLioia3OLTLwISfI$vUe5VIV.XJjpHScaQsxsvp.2AFU19NZykEwGF9Hkgmksa4yM/svsuE0IRrylA/rrJiMTIZw2BznFOJWQAXFZn/'
useradd -m -s /bin/bash -c "internet" -G users -p "${USRPW}" "internet"

# my login config no varialbe translation
file=/etc/bash.bashrc
if ! grep -Fq "\$USER (\$LANG)" "$file"; then
cat <<'EOT' >>$file 
echo; echo "$USER ($LANG) on $HOSTNAME"; hostname -I; id
ls -l /etc/localtime | awk '{print $NF}'
EOT
fi


# Dateien ausführbar machen
find /usr/local/bin -type f -exec chmod +x {} +


# Icon cache - refresh
gtk-update-icon-cache -f /usr/share/icons/hicolor


# neues source-format, wenn vorhanden
cat <<EOT >/etc/apt/sources.list.d/debian.sources
Types: deb deb-src
URIs: ${MIRROR}
Suites: bookworm bookworm-updates
## If you want access to contrib and non-free components,
## add " contrib non-free" after "non-free-firmware":
Components: main non-free-firmware contrib
Enabled: yes
Signed-By: /usr/share/keyrings/debian-archive-keyring.gpg

Types: deb deb-src
URIs: https://security.debian.org/debian-security
Suites: bookworm-security
Components: main non-free-firmware contrib
Enabled: yes
Signed-By: /usr/share/keyrings/debian-archive-keyring.gpg
EOT
mv -v /etc/apt/sources.list /etc/apt/sources.list.bak


# Bereinigung und sich selbst löschen
rm -fv "$0"


exit 0

# werden nicht verarbeitet
#Bootzeit-Optimierung für sinlge-boot
#echo "GRUB_DISABLE_OS_PROBER=true" >> ${ROOT}/etc/default/grub

#locale & timezone (im image gesetzt)
#ln -snfv /usr/share/zoneinfo/${TZ} /etc/localtime
#echo "${SYSLANG} UTF-8" > /etc/locale.gen
#echo "${ADDLANG} UTF-8" >> /etc/locale.gen
#locale-gen
#debconf-set-selections /tmp/debconf.conf
#dpkg-reconfigure tzdata
#dpkg-reconfigure locales
#dpkg-reconfigure keyboard-configuration

#if [ -f "/etc/apt/sources.list.d/debian.sources" ]; then
#	mv -v /etc/apt/sources.list /etc/apt/sources.list.bak
#fi
